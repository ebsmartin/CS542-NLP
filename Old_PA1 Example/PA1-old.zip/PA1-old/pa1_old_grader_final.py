# Final autograder for PA1
# =========================
import numpy as np
import argparse
import importlib
import re
import traceback

# Track sumbission score
score = 0
max_score = 60

# Prompt for manual input
def yes_or_no():
    while "the answer is invalid":
        reply = input('Correct? (y/n): ').lower().strip()
        if reply[0] == 'y':
            return True
        if reply[0] == 'n':
            return False

# Log running score
def update_score(inc):
    global score
    score += inc
    print(f'\nScore: {score}/{max_score}\n')

# Allow student submission to be passed in as an argument
parser = argparse.ArgumentParser(description='PA1 grader')
parser.add_argument('filename', nargs='?', default='naive_bayes.py', type=str)
args = parser.parse_args()
student = re.findall(r'^[^_]+(?=_)', args.filename)[0]
print(f'''
================
Submission: {student}
================
''')

print('''
1. Initialize NaiveBayes class from student solution
====================================================''')

# Import student class via given filename
module_name = re.findall(r'^.*(?=.py$)', args.filename)[0]
naive_bayes = importlib.import_module(module_name)

# Initialize object
nb = naive_bayes.NaiveBayes()

# Override object attributes for use with test data
nb.class_dict = {'neg': 0, 'pos': 1}

def select_features_test(*_):
    return {'good': 0,
            'bad': 1, 
            'least': 2, 
            'best': 3, 
            'great': 4,
            'however': 5,
            'should': 6,
            'would': 7,
            'performance': 8,
            'love': 9,
            'terrible': 10,
            'awesome': 11}

nb.select_features = select_features_test

print('PASSED')

print('''
2. Train classifier on movie_reviews dataset
============================================''')

try:
    nb.train('movie_reviews/train')
    print('PASSED')

    print('''
3. Testing prior and likelihood... (20 pts)
===========================================''')

    correct_prior = np.array([-0.69439796, -0.69189796])
    correct_likelihood = np.array([[ -6.49795891,  -6.62065596,  -7.4971104 ,  -7.32619487,
            -7.61304603,  -7.46508438,  -7.28947104,  -6.59512266,
            -7.72544492,  -7.47083152,  -8.79836772, -11.24071476],
        [ -6.57355575,  -7.73226258,  -8.02445933,  -6.91833386,
            -7.02903128,  -7.31559914,  -7.79500092,  -6.72558778,
            -7.33584731,  -7.1980636 , -10.16452549, -10.28712782]])

    if(
        (np.allclose(np.array(nb.prior), correct_prior) or 
        np.allclose(np.array(nb.prior), np.flip(correct_prior, axis=0))) and
        (np.allclose(np.array(nb.likelihood), correct_likelihood) or
        np.allclose(np.array(nb.likelihood), np.flip(correct_likelihood, axis=0))) 
        ):
        print('PASSED')
        update_score(20)
    else:
        print('FAILED \nCorrect:')
        print(f'\tnb.prior = {correct_prior}')
        print(f'\tnb.likelihood = \n{correct_likelihood}')
        print('Output:')
        print(f'\tnb.prior = {nb.prior}')
        print(f'\tnb.likelihood = \n{nb.likelihood}')
except Exception:
    traceback.print_exc()

print('''
4. Test results output from test method... (10 pts)
===================================================''')

try:
    correct_results = {'cv799_19812.txt': {'correct': 0, 'predicted': 0},
                'cv800_13494.txt': {'correct': 0, 'predicted': 0},
                'cv801_25228.txt': {'correct': 1, 'predicted': 1},
                'cv801_26335.txt': {'correct': 0, 'predicted': 0},
                'cv802_28381.txt': {'correct': 0, 'predicted': 1},
                'cv802_28664.txt': {'correct': 1, 'predicted': 1},
                'cv803_8207.txt': {'correct': 1, 'predicted': 1},
                'cv803_8584.txt': {'correct': 0, 'predicted': 0},
                'cv804_10862.txt': {'correct': 1, 'predicted': 1},
                'cv804_11763.txt': {'correct': 0, 'predicted': 0},
                'cv805_19601.txt': {'correct': 1, 'predicted': 1},
                'cv805_21128.txt': {'correct': 0, 'predicted': 1},
                'cv806_8842.txt': {'correct': 1, 'predicted': 0},
                'cv806_9405.txt': {'correct': 0, 'predicted': 0},
                'cv807_21740.txt': {'correct': 1, 'predicted': 0},
                'cv807_23024.txt': {'correct': 0, 'predicted': 0},
                'cv808_12635.txt': {'correct': 1, 'predicted': 1},
                'cv808_13773.txt': {'correct': 0, 'predicted': 1},
                'cv809_5009.txt': {'correct': 1, 'predicted': 1},
                'cv809_5012.txt': {'correct': 0, 'predicted': 0},
                'cv810_12458.txt': {'correct': 1, 'predicted': 0},
                'cv810_13660.txt': {'correct': 0, 'predicted': 1},
                'cv811_21386.txt': {'correct': 1, 'predicted': 0},
                'cv811_22646.txt': {'correct': 0, 'predicted': 1},
                'cv812_17924.txt': {'correct': 1, 'predicted': 1},
                'cv812_19051.txt': {'correct': 0, 'predicted': 0},
                'cv813_6534.txt': {'correct': 1, 'predicted': 1},
                'cv813_6649.txt': {'correct': 0, 'predicted': 0},
                'cv814_18975.txt': {'correct': 1, 'predicted': 1},
                'cv814_20316.txt': {'correct': 0, 'predicted': 0},
                'cv815_22456.txt': {'correct': 1, 'predicted': 0},
                'cv815_23466.txt': {'correct': 0, 'predicted': 1},
                'cv816_13655.txt': {'correct': 1, 'predicted': 1},
                'cv816_15257.txt': {'correct': 0, 'predicted': 0},
                'cv817_3675.txt': {'correct': 0, 'predicted': 0},
                'cv817_4041.txt': {'correct': 1, 'predicted': 1},
                'cv818_10211.txt': {'correct': 1, 'predicted': 1},
                'cv818_10698.txt': {'correct': 0, 'predicted': 1},
                'cv819_9364.txt': {'correct': 1, 'predicted': 1},
                'cv819_9567.txt': {'correct': 0, 'predicted': 0},
                'cv820_22892.txt': {'correct': 1, 'predicted': 0},
                'cv820_24157.txt': {'correct': 0, 'predicted': 0},
                'cv821_29283.txt': {'correct': 0, 'predicted': 1},
                'cv821_29364.txt': {'correct': 1, 'predicted': 1},
                'cv822_20049.txt': {'correct': 1, 'predicted': 0},
                'cv822_21545.txt': {'correct': 0, 'predicted': 0},
                'cv823_15569.txt': {'correct': 1, 'predicted': 1},
                'cv823_17055.txt': {'correct': 0, 'predicted': 0},
                'cv824_8838.txt': {'correct': 1, 'predicted': 0},
                'cv824_9335.txt': {'correct': 0, 'predicted': 0},
                'cv825_5063.txt': {'correct': 1, 'predicted': 0},
                'cv825_5168.txt': {'correct': 0, 'predicted': 0},
                'cv826_11834.txt': {'correct': 1, 'predicted': 1},
                'cv826_12761.txt': {'correct': 0, 'predicted': 1},
                'cv827_18331.txt': {'correct': 1, 'predicted': 1},
                'cv827_19479.txt': {'correct': 0, 'predicted': 0},
                'cv828_19831.txt': {'correct': 1, 'predicted': 0},
                'cv828_21392.txt': {'correct': 0, 'predicted': 1},
                'cv829_20289.txt': {'correct': 1, 'predicted': 1},
                'cv829_21725.txt': {'correct': 0, 'predicted': 0},
                'cv830_5778.txt': {'correct': 0, 'predicted': 0},
                'cv830_6014.txt': {'correct': 1, 'predicted': 1},
                'cv831_14689.txt': {'correct': 1, 'predicted': 0},
                'cv831_16325.txt': {'correct': 0, 'predicted': 1},
                'cv832_23275.txt': {'correct': 1, 'predicted': 0},
                'cv832_24713.txt': {'correct': 0, 'predicted': 1},
                'cv833_11053.txt': {'correct': 1, 'predicted': 0},
                'cv833_11961.txt': {'correct': 0, 'predicted': 0},
                'cv834_22195.txt': {'correct': 1, 'predicted': 0},
                'cv834_23192.txt': {'correct': 0, 'predicted': 0},
                'cv835_19159.txt': {'correct': 1, 'predicted': 1},
                'cv835_20531.txt': {'correct': 0, 'predicted': 0},
                'cv836_12968.txt': {'correct': 1, 'predicted': 0},
                'cv836_14311.txt': {'correct': 0, 'predicted': 0},
                'cv837_27232.txt': {'correct': 0, 'predicted': 0},
                'cv837_27325.txt': {'correct': 1, 'predicted': 1},
                'cv838_24728.txt': {'correct': 1, 'predicted': 0},
                'cv838_25886.txt': {'correct': 0, 'predicted': 1},
                'cv839_21467.txt': {'correct': 1, 'predicted': 1},
                'cv839_22807.txt': {'correct': 0, 'predicted': 0},
                'cv840_16321.txt': {'correct': 1, 'predicted': 0},
                'cv840_18033.txt': {'correct': 0, 'predicted': 0},
                'cv841_3367.txt': {'correct': 0, 'predicted': 1},
                'cv841_3967.txt': {'correct': 1, 'predicted': 0},
                'cv842_5702.txt': {'correct': 0, 'predicted': 0},
                'cv842_5866.txt': {'correct': 1, 'predicted': 0},
                'cv843_15544.txt': {'correct': 1, 'predicted': 1},
                'cv843_17054.txt': {'correct': 0, 'predicted': 1},
                'cv844_12690.txt': {'correct': 1, 'predicted': 0},
                'cv844_13890.txt': {'correct': 0, 'predicted': 0},
                'cv845_14290.txt': {'correct': 1, 'predicted': 1},
                'cv845_15886.txt': {'correct': 0, 'predicted': 1},
                'cv846_29359.txt': {'correct': 0, 'predicted': 0},
                'cv846_29497.txt': {'correct': 1, 'predicted': 0},
                'cv847_1941.txt': {'correct': 1, 'predicted': 1},
                'cv847_20855.txt': {'correct': 0, 'predicted': 0},
                'cv848_10036.txt': {'correct': 1, 'predicted': 1},
                'cv848_10061.txt': {'correct': 0, 'predicted': 0},
                'cv849_15729.txt': {'correct': 1, 'predicted': 1},
                'cv849_17215.txt': {'correct': 0, 'predicted': 0},
                'cv850_16466.txt': {'correct': 1, 'predicted': 1},
                'cv850_18185.txt': {'correct': 0, 'predicted': 0},
                'cv851_20469.txt': {'correct': 1, 'predicted': 1},
                'cv851_21895.txt': {'correct': 0, 'predicted': 1},
                'cv852_27512.txt': {'correct': 0, 'predicted': 1},
                'cv852_27523.txt': {'correct': 1, 'predicted': 1},
                'cv853_29119.txt': {'correct': 0, 'predicted': 1},
                'cv853_29233.txt': {'correct': 1, 'predicted': 1},
                'cv854_17740.txt': {'correct': 1, 'predicted': 1},
                'cv854_18955.txt': {'correct': 0, 'predicted': 0},
                'cv855_20661.txt': {'correct': 1, 'predicted': 1},
                'cv855_22134.txt': {'correct': 0, 'predicted': 0},
                'cv856_28882.txt': {'correct': 0, 'predicted': 0},
                'cv856_29013.txt': {'correct': 1, 'predicted': 0},
                'cv857_15958.txt': {'correct': 1, 'predicted': 1},
                'cv857_17527.txt': {'correct': 0, 'predicted': 0},
                'cv858_18819.txt': {'correct': 1, 'predicted': 1},
                'cv858_20266.txt': {'correct': 0, 'predicted': 0},
                'cv859_14107.txt': {'correct': 1, 'predicted': 0},
                'cv859_15689.txt': {'correct': 0, 'predicted': 0},
                'cv860_13853.txt': {'correct': 1, 'predicted': 1},
                'cv860_15520.txt': {'correct': 0, 'predicted': 0},
                'cv861_1198.txt': {'correct': 1, 'predicted': 0},
                'cv861_12809.txt': {'correct': 0, 'predicted': 1},
                'cv862_14324.txt': {'correct': 1, 'predicted': 1},
                'cv862_15924.txt': {'correct': 0, 'predicted': 1},
                'cv863_7424.txt': {'correct': 1, 'predicted': 1},
                'cv863_7912.txt': {'correct': 0, 'predicted': 0},
                'cv864_3087.txt': {'correct': 0, 'predicted': 0},
                'cv864_3416.txt': {'correct': 1, 'predicted': 1},
                'cv865_28796.txt': {'correct': 0, 'predicted': 0},
                'cv865_2895.txt': {'correct': 1, 'predicted': 1},
                'cv866_29447.txt': {'correct': 0, 'predicted': 1},
                'cv866_29691.txt': {'correct': 1, 'predicted': 1},
                'cv867_16661.txt': {'correct': 1, 'predicted': 1},
                'cv867_18362.txt': {'correct': 0, 'predicted': 0},
                'cv868_11948.txt': {'correct': 1, 'predicted': 1},
                'cv868_12799.txt': {'correct': 0, 'predicted': 0},
                'cv869_23611.txt': {'correct': 1, 'predicted': 1},
                'cv869_24782.txt': {'correct': 0, 'predicted': 0},
                'cv870_16348.txt': {'correct': 1, 'predicted': 1},
                'cv870_18090.txt': {'correct': 0, 'predicted': 1},
                'cv871_24888.txt': {'correct': 1, 'predicted': 0},
                'cv871_25971.txt': {'correct': 0, 'predicted': 0},
                'cv872_12591.txt': {'correct': 1, 'predicted': 1},
                'cv872_13710.txt': {'correct': 0, 'predicted': 0},
                'cv873_18636.txt': {'correct': 1, 'predicted': 1},
                'cv873_19937.txt': {'correct': 0, 'predicted': 0},
                'cv874_11236.txt': {'correct': 1, 'predicted': 0},
                'cv874_12182.txt': {'correct': 0, 'predicted': 0},
                'cv875_5622.txt': {'correct': 0, 'predicted': 1},
                'cv875_5754.txt': {'correct': 1, 'predicted': 1},
                'cv876_9390.txt': {'correct': 1, 'predicted': 1},
                'cv876_9633.txt': {'correct': 0, 'predicted': 0},
                'cv877_29132.txt': {'correct': 0, 'predicted': 0},
                'cv877_29274.txt': {'correct': 1, 'predicted': 1},
                'cv878_15694.txt': {'correct': 1, 'predicted': 1},
                'cv878_17204.txt': {'correct': 0, 'predicted': 0},
                'cv879_14903.txt': {'correct': 1, 'predicted': 1},
                'cv879_16585.txt': {'correct': 0, 'predicted': 1},
                'cv880_29629.txt': {'correct': 0, 'predicted': 1},
                'cv880_29800.txt': {'correct': 1, 'predicted': 1},
                'cv881_13254.txt': {'correct': 1, 'predicted': 1},
                'cv881_14767.txt': {'correct': 0, 'predicted': 1},
                'cv882_10026.txt': {'correct': 1, 'predicted': 0},
                'cv882_10042.txt': {'correct': 0, 'predicted': 0},
                'cv883_27621.txt': {'correct': 0, 'predicted': 0},
                'cv883_27751.txt': {'correct': 1, 'predicted': 1},
                'cv884_13632.txt': {'correct': 1, 'predicted': 1},
                'cv884_15230.txt': {'correct': 0, 'predicted': 0},
                'cv885_12318.txt': {'correct': 1, 'predicted': 1},
                'cv885_13390.txt': {'correct': 0, 'predicted': 1},
                'cv886_18177.txt': {'correct': 1, 'predicted': 0},
                'cv886_19210.txt': {'correct': 0, 'predicted': 0},
                'cv887_5126.txt': {'correct': 1, 'predicted': 1},
                'cv887_5306.txt': {'correct': 0, 'predicted': 0},
                'cv888_24435.txt': {'correct': 1, 'predicted': 0},
                'cv888_25678.txt': {'correct': 0, 'predicted': 1},
                'cv889_21430.txt': {'correct': 1, 'predicted': 1},
                'cv889_22670.txt': {'correct': 0, 'predicted': 1},
                'cv890_3515.txt': {'correct': 0, 'predicted': 0},
                'cv890_3977.txt': {'correct': 1, 'predicted': 0},
                'cv891_6035.txt': {'correct': 0, 'predicted': 0},
                'cv891_6385.txt': {'correct': 1, 'predicted': 0},
                'cv892_17576.txt': {'correct': 1, 'predicted': 1},
                'cv892_18788.txt': {'correct': 0, 'predicted': 1},
                'cv893_26269.txt': {'correct': 1, 'predicted': 1},
                'cv893_26731.txt': {'correct': 0, 'predicted': 0},
                'cv894_2068.txt': {'correct': 1, 'predicted': 1},
                'cv894_22140.txt': {'correct': 0, 'predicted': 0},
                'cv895_21022.txt': {'correct': 1, 'predicted': 1},
                'cv895_22200.txt': {'correct': 0, 'predicted': 0},
                'cv896_16071.txt': {'correct': 1, 'predicted': 1},
                'cv896_17819.txt': {'correct': 0, 'predicted': 0},
                'cv897_10837.txt': {'correct': 1, 'predicted': 0},
                'cv897_11703.txt': {'correct': 0, 'predicted': 0},
                'cv898_14187.txt': {'correct': 1, 'predicted': 1},
                'cv898_1576.txt': {'correct': 0, 'predicted': 0},
                'cv899_16014.txt': {'correct': 1, 'predicted': 1},
                'cv899_17812.txt': {'correct': 0, 'predicted': 0}}

    results = nb.test('movie_reviews/dev')

    if(correct_results == dict(results)):
        print('PASSED')
        update_score(10)
    else:
        print('Correct:')
        print(correct_results)
        print('Output:')
        print(dict(results))
        print('FAILED')

except Exception:
    traceback.print_exc()

try:
    print('''
5. Test evaluate method output... (10 pts)
==========================================''')

    nb.evaluate(correct_results)
    print('''
Correct output:
For class neg:
    Precision: 0.6862745098039216
    Recall: 0.693069306930693
    F1: 0.6896551724137931
For class pos:
    Precision: 0.6836734693877551
    Recall: 0.6767676767676768
    F1: 0.6802030456852791
Accuracy: 0.685
    ''')

    if yes_or_no():
        print('\nPASSED')
        update_score(10)
    else:
        print('FAILED')
except Exception:
    traceback.print_exc()

print('''
6. Manual check of select_features... (20 pts)
==============================================''')

if yes_or_no():
    print('\nPASSED')
    update_score(20)
else:
    print('FAILED')

print(f'''
======================
FINAL SCORE: {score}/{max_score}
''')
