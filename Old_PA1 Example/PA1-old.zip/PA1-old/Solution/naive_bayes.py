# CS542 Fall 2022 Programming Assignment 1
# Naive Bayes Classifier and Evaluation

import os
import numpy as np
from collections import defaultdict
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report

class NaiveBayes():

    def __init__(self):
        # be sure to use the right class_dict for each data set
        self.class_dict = {'neg': 0, 'pos': 1}
        #self.class_dict = {'action': 0, 'comedy': 1}
        self.feature_dict = {}
        self.prior = None
        self.likelihood = None

    '''
    Trains a multinomial Naive Bayes classifier on a training set.
    Specifically, fills in self.prior and self.likelihood such that:
    self.prior[class] = log(P(class))
    self.likelihood[class][feature] = log(P(feature|class))
    '''
    def train(self, train_set):
        doc_count = 0
        bigdoc_counts = defaultdict(int)
        vocabulary = set()
        prior_counts = defaultdict(int)
        likelihood_counts = defaultdict(lambda: defaultdict(int))
        self.feature_dict = self.select_features(train_set)
        # iterate over training documents
        for root, dirs, files in os.walk(train_set):
            for name in files:
                with open(os.path.join(root, name)) as f:
                    # collect class counts and feature counts
                    c = root.split('/')[-1]
                    words = f.read().split()
                    doc_count += 1
                    bigdoc_counts[c] += len(words)
                    vocabulary.update(words)
                    prior_counts[c] += 1
                    for word in words:
                        if word in self.feature_dict:
                            likelihood_counts[c][word] += 1
        self.feature_dict = self.select_features(train_set)
        self.prior = np.zeros(len(self.class_dict))
        self.likelihood = np.zeros((len(self.class_dict),
                                    len(self.feature_dict)))
        # normalize counts to probabilities, and take logs
        for c, i in self.class_dict.items():
            self.prior[i] = prior_counts[c] / doc_count
            for word, j in self.feature_dict.items():
                self.likelihood[i, j] = ((likelihood_counts[c][word] + 1)
                                         / (bigdoc_counts[c] + len(vocabulary)))
        self.prior = np.log(self.prior)
        self.likelihood = np.log(self.likelihood)

    '''
    Tests the classifier on a development or test set.
    Returns a dictionary of filenames mapped to their correct and predicted
    classes such that:
    results[filename]['correct'] = correct class
    results[filename]['predicted'] = predicted class
    '''
    def test(self, dev_set):
        results = defaultdict(dict)
        # iterate over testing documents
        for root, dirs, files in os.walk(dev_set):
            for name in files:
                with open(os.path.join(root, name)) as f:
                    # create feature vectors for each document
                    words = f.read().split()
                    vector = np.zeros(len(self.feature_dict))
                    for word in words:
                        if word in self.feature_dict:
                            vector[self.feature_dict[word]] += 1
                # get most likely class
                probs = self.prior + np.dot(self.likelihood, vector)
                results[name]['correct'] = self.class_dict[root.split('/')[-1]]
                results[name]['predicted'] = np.argmax(probs)
        return results

    '''
    Given results, calculates the following:
    Precision, Recall, F1 for each class
    Accuracy overall
    Also, prints evaluation metrics in readable format.
    '''
    def evaluate(self, results):
        # this is sklearn's implementation
        # DO NOT COPY THIS CODE FOR PA1
        correct = [results[name]['correct'] for name in results]
        predicted = [results[name]['predicted'] for name in results]
        cm = confusion_matrix(predicted,correct,labels=[0, 1])
        report = classification_report(predicted,correct)
        print("\t 0\t1")
        print("0\t","\t".join(str(cm[0,:]).replace('[','').replace(']','').strip().split()))
        print("1\t","\t".join(str(cm[1,:]).replace('[','').replace(']','').strip().split()))
        print(report)

    '''
    Performs feature selection.
    Returns a dictionary of features.
    '''
    def select_features(self, train_set):
        # almost any method of feature selection is fine here
        return {'fast': 0, 'couple': 1, 'shoot': 2, 'fly': 3}

if __name__ == '__main__':
    nb = NaiveBayes()
    # make sure these point to the right directories
    nb.train('movie_reviews/train')
    #nb.train('movie_reviews_small/train')
    results = nb.test('movie_reviews/dev')
    #results = nb.test('movie_reviews_small/test')
    nb.evaluate(results)
